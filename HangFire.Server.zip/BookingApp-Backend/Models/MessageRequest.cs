﻿namespace BookingApp_Backend.Models
{
    public class MessageRequest
    {
        
            public string? Name { get; set; }
            public string? Email { get; set; }
            public string? Subject { get; set; }
            public string? Message { get; set; }
        
    }
}
